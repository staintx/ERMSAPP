package com.eventreservationapp.adapters;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.eventreservationapp.R;
import com.eventreservationapp.models.Addon;
import com.eventreservationapp.models.OrderAddon;

import java.util.List;
import java.util.Locale;

public class AddonSelectionAdapter extends ArrayAdapter<Addon> {
    private final List<OrderAddon> selectedAddons;

    public AddonSelectionAdapter(Context context, List<Addon> addons, List<OrderAddon> selectedAddons) {
        super(context, 0, addons);
        this.selectedAddons = selectedAddons;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_addon_selection, parent, false);
        }

        Addon addon = getItem(position);
        if (addon == null) {
            return convertView;
        }

        TextView tvAddonName = convertView.findViewById(R.id.tvAddonName);
        TextView tvAddonDescription = convertView.findViewById(R.id.tvAddonDescription);
        TextView tvAddonPrice = convertView.findViewById(R.id.tvAddonPrice);
        EditText etQuantity = convertView.findViewById(R.id.etQuantity);
        Button btnAddAddon = convertView.findViewById(R.id.btnAddAddon);

        // Set addon details
        tvAddonName.setText(addon.getName());

        if (!TextUtils.isEmpty(addon.getDescription())) {
            tvAddonDescription.setText(addon.getDescription());
            tvAddonDescription.setVisibility(View.VISIBLE);
        } else {
            tvAddonDescription.setVisibility(View.GONE);
        }

        tvAddonPrice.setText(String.format(Locale.getDefault(), "₱%.2f", addon.getPrice()));

        // Check if this addon is already selected
        OrderAddon existingAddon = findExistingAddon(addon.getAddonId());
        if (existingAddon != null) {
            etQuantity.setText(String.valueOf(existingAddon.getQuantity()));
            btnAddAddon.setText("Update");
        } else {
            etQuantity.setText("1");
            btnAddAddon.setText("Add");
        }

        // Set up add/update button
        btnAddAddon.setOnClickListener(v -> {
            String quantityStr = etQuantity.getText().toString().trim();
            if (TextUtils.isEmpty(quantityStr)) {
                Toast.makeText(getContext(), "Please enter a quantity", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                int quantity = Integer.parseInt(quantityStr);
                if (quantity <= 0) {
                    Toast.makeText(getContext(), "Quantity must be greater than 0", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (existingAddon != null) {
                    // Update existing addon
                    existingAddon.setQuantity(quantity);
                    existingAddon.setTotalPrice(addon.getPrice() * quantity);
                    Toast.makeText(getContext(), "Addon updated", Toast.LENGTH_SHORT).show();
                } else {
                    // Add new addon
                    OrderAddon newAddon = new OrderAddon();
                    newAddon.setAddonId(addon.getAddonId());
                    newAddon.setName(addon.getName());
                    newAddon.setDescription(addon.getDescription());
                    newAddon.setQuantity(quantity);
                    newAddon.setTotalPrice(addon.getPrice() * quantity);
                    selectedAddons.add(newAddon);

                    // Update button text
                    btnAddAddon.setText("Update");
                    Toast.makeText(getContext(), "Addon added", Toast.LENGTH_SHORT).show();
                }
            } catch (NumberFormatException e) {
                Toast.makeText(getContext(), "Please enter a valid quantity", Toast.LENGTH_SHORT).show();
            }
        });

        return convertView;
    }

    /**
     * Find an existing addon in the selected addons list by addon ID
     * @param addonId The addon ID to search for
     * @return The OrderAddon if found, null otherwise
     */
    private OrderAddon findExistingAddon(int addonId) {
        for (OrderAddon orderAddon : selectedAddons) {
            if (orderAddon.getAddonId() == addonId) {
                return orderAddon;
            }
        }
        return null;
    }

    /**
     * Remove an addon from the selected list
     * @param addonId The addon ID to remove
     * @return true if removed, false if not found
     */
    public boolean removeAddon(int addonId) {
        OrderAddon toRemove = null;
        for (OrderAddon orderAddon : selectedAddons) {
            if (orderAddon.getAddonId() == addonId) {
                toRemove = orderAddon;
                break;
            }
        }

        if (toRemove != null) {
            return selectedAddons.remove(toRemove);
        }
        return false;
    }

    /**
     * Get the total price of all selected addons
     * @return The total price
     */
    public double getTotalAddonsPrice() {
        double total = 0;
        for (OrderAddon orderAddon : selectedAddons) {
            total += orderAddon.getTotalPrice();
        }
        return total;
    }
}