package com.eventreservationapp;

import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.eventreservationapp.models.SessionManager;
import com.eventreservationapp.models.UserData;

import org.json.JSONException;
import org.json.JSONObject;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

public class ProfileFragment extends Fragment {

    private static final String TAG = "ProfileFragment";

    private EditText etFullName;
    private EditText etEmail;
    private EditText etCurrentPassword;
    private EditText etNewPassword;
    private EditText etConfirmNewPassword;
    private Button btnSaveChanges;

    private RequestQueue rQueue;
    private SessionManager sessionManager;
    private UserData userData;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        // Initialize session manager to get user data
        sessionManager = new SessionManager(getContext());
        userData = sessionManager.getUserData();

        // Initialize views
        initializeViews(view);

        // Populate profile fields with current user data
        populateUserData();

        // Setup save button click listener
        setupSaveButton();

        return view;
    }

    private void initializeViews(View view) {
        etFullName = view.findViewById(R.id.etFullName);
        etEmail = view.findViewById(R.id.etEmail);
        etCurrentPassword = view.findViewById(R.id.etCurrentPassword);
        etNewPassword = view.findViewById(R.id.etNewPassword);
        etConfirmNewPassword = view.findViewById(R.id.etConfirmNewPassword);
        btnSaveChanges = view.findViewById(R.id.btnSaveChanges);
    }

    private void populateUserData() {
        if (userData != null) {
            etFullName.setText(userData.getFirstName() + " " + userData.getLastName());
            etEmail.setText(userData.getEmail());
        }
    }

    private void setupSaveButton() {
        btnSaveChanges.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateInputs()) {
                    updateUserProfile();
                }
            }
        });
    }

    private boolean validateInputs() {
        String fullName = etFullName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String currentPassword = etCurrentPassword.getText().toString().trim();
        String newPassword = etNewPassword.getText().toString().trim();
        String confirmNewPassword = etConfirmNewPassword.getText().toString().trim();

        // Validate full name
        if (fullName.isEmpty()) {
            etFullName.setError("Full name is required");
            etFullName.requestFocus();
            return false;
        }

        // Validate email
        if (email.isEmpty()) {
            etEmail.setError("Email is required");
            etEmail.requestFocus();
            return false;
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.setError("Please enter a valid email address");
            etEmail.requestFocus();
            return false;
        }

        // Password validation - only if user is trying to change password
        if (!currentPassword.isEmpty() || !newPassword.isEmpty() || !confirmNewPassword.isEmpty()) {
            // Current password is required when changing password
            if (currentPassword.isEmpty()) {
                etCurrentPassword.setError("Current password is required");
                etCurrentPassword.requestFocus();
                return false;
            }

            // New password validation
            if (newPassword.isEmpty()) {
                etNewPassword.setError("New password is required");
                etNewPassword.requestFocus();
                return false;
            }
            if (newPassword.length() < 6) {
                etNewPassword.setError("Password must be at least 6 characters long");
                etNewPassword.requestFocus();
                return false;
            }

            // Confirm password validation
            if (confirmNewPassword.isEmpty()) {
                etConfirmNewPassword.setError("Please confirm your new password");
                etConfirmNewPassword.requestFocus();
                return false;
            }
            if (!confirmNewPassword.equals(newPassword)) {
                etConfirmNewPassword.setError("Passwords do not match");
                etConfirmNewPassword.requestFocus();
                return false;
            }
        }

        return true;
    }

    private void updateUserProfile() {
        // Get input values
        String fullName = etFullName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String currentPassword = etCurrentPassword.getText().toString().trim();
        String newPassword = etNewPassword.getText().toString().trim();

        // Split full name into first and last name
        String[] nameParts = fullName.split(" ", 2);
        String firstName = nameParts[0];
        String lastName = nameParts.length > 1 ? nameParts[1] : "";

        // Hash passwords if provided
        String hashedCurrentPassword = !currentPassword.isEmpty() ? md5(currentPassword) : "";
        String hashedNewPassword = !newPassword.isEmpty() ? md5(newPassword) : "";

        // Show progress to user
        btnSaveChanges.setEnabled(false);
        Toast.makeText(getContext(), "Saving changes...", Toast.LENGTH_SHORT).show();

        // Initialize RequestQueue if not already initialized
        if (rQueue == null) {
            rQueue = Volley.newRequestQueue(getContext());
        }

        StringRequest stringRequest = createUpdateProfileRequest(
                firstName, lastName, email, hashedCurrentPassword, hashedNewPassword);

        // Set timeout for the request
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                30000, // 30 seconds timeout
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
        ));

        // Add request to queue
        rQueue.add(stringRequest);
    }

    private StringRequest createUpdateProfileRequest(final String firstName, final String lastName,
                                                     final String email, final String currentPassword,
                                                     final String newPassword) {

        return new StringRequest(Request.Method.POST,
                getResources().getString(R.string.url) + "app_api/update_profile.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        handleUpdateResponse(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        btnSaveChanges.setEnabled(true);
                        Log.e(TAG, "Update Error: " + error.toString());
                        Toast.makeText(getContext(),
                                "Network error occurred. Please try again.",
                                Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("user_id", String.valueOf(userData.getUserId()));
                params.put("first_name", firstName);
                params.put("last_name", lastName);
                params.put("email", email);

                // Only include password params if user is trying to change password
                if (!currentPassword.isEmpty() && !newPassword.isEmpty()) {
                    params.put("current_password", currentPassword);
                    params.put("new_password", newPassword);
                }

                return params;
            }

            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/x-www-form-urlencoded");
                headers.put("X-Requested-With", "XMLHttpRequest");
                return headers;
            }
        };
    }

    private void handleUpdateResponse(String response) {
        btnSaveChanges.setEnabled(true);
        Log.d(TAG, "Update Response: " + response);

        try {
            JSONObject jsonResponse = new JSONObject(response);
            String success = jsonResponse.optString("success");
            String message = jsonResponse.optString("message", "Unknown error occurred");

            if (success.equals("1")) {
                // Update successful
                Toast.makeText(getContext(), "Profile updated successfully!", Toast.LENGTH_SHORT).show();

                // If response contains updated user data, update session
                if (jsonResponse.has("details")) {
                    JSONObject details = jsonResponse.getJSONObject("details");
                    UserData updatedUserData = new UserData(
                            userData.getUserId(),
                            details.optString("username", userData.getUsername()),
                            details.optString("useremail", userData.getEmail()),
                            details.optString("first_name", userData.getFirstName()),
                            details.optString("last_name", userData.getLastName())
                    );
                    sessionManager.updateUserData(updatedUserData);

                    // Refresh displayed user data
                    userData = sessionManager.getUserData();
                    populateUserData();
                }

                // Clear password fields
                etCurrentPassword.setText("");
                etNewPassword.setText("");
                etConfirmNewPassword.setText("");
            } else {
                // Update failed
                Toast.makeText(getContext(), message, Toast.LENGTH_LONG).show();
            }
        } catch (JSONException e) {
            Log.e(TAG, "JSON parsing error: " + e.getMessage());
            Toast.makeText(getContext(),
                    "Error processing server response", Toast.LENGTH_SHORT).show();
        }
    }

    // MD5 hashing function (same as in RegisterActivity)
    private static String md5(final String s) {
        try {
            // Create MD5 Hash
            MessageDigest digest = MessageDigest.getInstance("MD5");
            digest.update(s.getBytes());
            byte[] messageDigest = digest.digest();

            // Create Hex String
            StringBuilder hexString = new StringBuilder();
            for (byte b : messageDigest) {
                String h = Integer.toHexString(0xFF & b);
                while (h.length() < 2)
                    h = "0" + h;
                hexString.append(h);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            Log.e(TAG, "Error hashing password: " + e.getMessage());
        }
        return "";
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (rQueue != null) {
            rQueue.cancelAll(TAG);
        }
    }
}