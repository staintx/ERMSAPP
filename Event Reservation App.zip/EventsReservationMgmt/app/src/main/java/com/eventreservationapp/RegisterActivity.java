package com.eventreservationapp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity {

    private static final String TAG = "RegisterActivity";

    private EditText etFirstName;
    private EditText etLastName;
    private EditText etEmail;
    private EditText etPhone;
    private EditText etAddress;
    private EditText etUsername;
    private EditText etPassword;
    private EditText etConfirmPassword;
    private Button btnRegister;
    private TextView tvLogin;
    private ProgressBar progressBar;

    private RequestQueue rQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Initialize views and setup
        initializeViews();
        setupRegisterButton();

        // Set up login text click listener
        tvLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate back to LoginActivity
                login(v);
            }
        });
    }

    private void initializeViews() {
        etFirstName = findViewById(R.id.etFirstName);
        etLastName = findViewById(R.id.etLastName);
        etEmail = findViewById(R.id.etEmail);
        etPhone = findViewById(R.id.etPhone);
        etAddress = findViewById(R.id.etAddress);
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        etConfirmPassword = findViewById(R.id.etConfirmPassword);
        btnRegister = findViewById(R.id.btnRegister);
        tvLogin = findViewById(R.id.tvLogin);
        progressBar = findViewById(R.id.progressBar);
    }

    private void setupRegisterButton() {
        btnRegister.setOnClickListener(view -> {
            if (validateInputs()) {
                performRegistration();
            }
        });
    }

    private boolean validateInputs() {
        // Get input values
        String firstName = etFirstName.getText().toString().trim();
        String lastName = etLastName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String confirmPassword = etConfirmPassword.getText().toString().trim();

        // First name validation
        if (firstName.isEmpty()) {
            etFirstName.setError("First name is required");
            etFirstName.requestFocus();
            return false;
        }

        // Last name validation
        if (lastName.isEmpty()) {
            etLastName.setError("Last name is required");
            etLastName.requestFocus();
            return false;
        }

        // Email validation
        if (email.isEmpty()) {
            etEmail.setError("Email is required");
            etEmail.requestFocus();
            return false;
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.setError("Please enter a valid email address");
            etEmail.requestFocus();
            return false;
        }

        // Phone validation
        if (phone.isEmpty()) {
            etPhone.setError("Phone number is required");
            etPhone.requestFocus();
            return false;
        }
        if (phone.length() < 10) {
            etPhone.setError("Please enter a valid phone number");
            etPhone.requestFocus();
            return false;
        }

        // Username validation
        if (username.isEmpty()) {
            etUsername.setError("Username is required");
            etUsername.requestFocus();
            return false;
        }
        if (username.length() < 3) {
            etUsername.setError("Username must be at least 3 characters long");
            etUsername.requestFocus();
            return false;
        }

        // Password validation
        if (password.isEmpty()) {
            etPassword.setError("Password is required");
            etPassword.requestFocus();
            return false;
        }
        if (password.length() < 6) {
            etPassword.setError("Password must be at least 6 characters long");
            etPassword.requestFocus();
            return false;
        }

        // Confirm password validation
        if (confirmPassword.isEmpty()) {
            etConfirmPassword.setError("Please confirm your password");
            etConfirmPassword.requestFocus();
            return false;
        }
        if (!confirmPassword.equals(password)) {
            etConfirmPassword.setError("Passwords do not match");
            etConfirmPassword.requestFocus();
            return false;
        }

        return true;
    }

    private void performRegistration() {
        // Get input values
        String firstName = etFirstName.getText().toString().trim();
        String lastName = etLastName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        String address = etAddress.getText().toString().trim();
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        // Hash the password
        String hashedPassword = md5(password);

        if (hashedPassword.isEmpty()) {
            Toast.makeText(this, "Error processing password", Toast.LENGTH_SHORT).show();
            return;
        }

        // Show progress to user
        progressBar.setVisibility(View.VISIBLE);
        btnRegister.setEnabled(false);
        Toast.makeText(this, "Processing registration...", Toast.LENGTH_SHORT).show();

        // Initialize RequestQueue if not already initialized
        if (rQueue == null) {
            rQueue = Volley.newRequestQueue(getApplicationContext());
        }

        StringRequest stringRequest = createRegistrationRequest(
                firstName, lastName, email, phone, address, username, hashedPassword);

        // Set timeout for the request
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                30000, // 30 seconds timeout
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
        ));

        // Add request to queue
        rQueue.add(stringRequest);
    }

    private StringRequest createRegistrationRequest(final String firstName, final String lastName,
                                                    final String email, final String phone,
                                                    final String address, final String username,
                                                    final String hashedPassword) {

        return new StringRequest(Request.Method.POST,
                getResources().getString(R.string.url) + "app_api/register.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        handleRegistrationResponse(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressBar.setVisibility(View.GONE);
                        btnRegister.setEnabled(true);
                        Log.e(TAG, "Registration Error: " + error.toString());
                        Toast.makeText(RegisterActivity.this,
                                "Network error occurred. Please try again.",
                                Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("first_name", firstName);
                params.put("last_name", lastName);
                params.put("useremail", email);
                params.put("phone", phone);
                params.put("address", address);
                params.put("username", username);
                params.put("password", hashedPassword);
                return params;
            }

            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/x-www-form-urlencoded");
                headers.put("X-Requested-With", "XMLHttpRequest");
                return headers;
            }
        };
    }

    private void handleRegistrationResponse(String response) {
        progressBar.setVisibility(View.GONE);
        btnRegister.setEnabled(true);
        Log.d(TAG, "Registration Response: " + response);

        try {
            JSONObject jsonResponse = new JSONObject(response);
            String success = jsonResponse.optString("success");
            String message = jsonResponse.optString("message", "Unknown error occurred");

            if (success.equals("1")) {
                // Registration successful
                JSONObject details = jsonResponse.getJSONObject("details");

                Toast.makeText(RegisterActivity.this, "Registration successful! Please login.", Toast.LENGTH_SHORT).show();

                // Navigate back to LoginActivity instead of MainActivity
                Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            } else {
                // Registration failed
                Toast.makeText(RegisterActivity.this, message, Toast.LENGTH_LONG).show();
            }
        } catch (JSONException e) {
            Log.e(TAG, "JSON parsing error: " + e.getMessage());
            Toast.makeText(RegisterActivity.this,
                    "Error processing server response", Toast.LENGTH_SHORT).show();
        }
    }

    // MD5 hashing function
    private static String md5(final String s) {
        try {
            // Create MD5 Hash
            MessageDigest digest = MessageDigest.getInstance("MD5");
            digest.update(s.getBytes());
            byte[] messageDigest = digest.digest();

            // Create Hex String
            StringBuilder hexString = new StringBuilder();
            for (byte b : messageDigest) {
                String h = Integer.toHexString(0xFF & b);
                while (h.length() < 2)
                    h = "0" + h;
                hexString.append(h);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            Log.e(TAG, "Error hashing password: " + e.getMessage());
        }
        return "";
    }

    public void login(View v) {
        startActivity(new Intent(this, LoginActivity.class));
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (rQueue != null) {
            rQueue.cancelAll(TAG);
        }
    }
}
/*============================================= PREVIOUS V1=============================================



/*package com.eventreservationapp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity {
    private static final String TAG = "RegisterActivity";
    private EditText tuseremail, tusername, tfirstname, tlastname, tphone, tpassword, tpassword1;
    private Button bregister;
    private RequestQueue rQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        initializeViews();
        setupRegisterButton();
    }

    private void initializeViews() {
        tuseremail = findViewById(R.id.useremail);
        tusername = findViewById(R.id.username);
        tfirstname = findViewById(R.id.firstname);
        tlastname = findViewById(R.id.lastname);
        tphone = findViewById(R.id.phone);
        tpassword = findViewById(R.id.password);
        tpassword1 = findViewById(R.id.password1);
        bregister = findViewById(R.id.register_btn);
    }

    private void setupRegisterButton() {
        bregister.setOnClickListener(view -> {
            if (validateInputs()) {
                performRegistration();
            }
        });
    }

    private boolean validateInputs() {
        String useremail = tuseremail.getText().toString().trim();
        String username = tusername.getText().toString().trim();
        String firstname = tfirstname.getText().toString().trim();
        String lastname = tlastname.getText().toString().trim();
        String phone = tphone.getText().toString().trim();
        String password = tpassword.getText().toString();
        String password1 = tpassword1.getText().toString();

        // Email validation
        if (useremail.isEmpty()) {
            tuseremail.setError("Email is required");
            tuseremail.requestFocus();
            return false;
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(useremail).matches()) {
            tuseremail.setError("Please enter a valid email address");
            tuseremail.requestFocus();
            return false;
        }

        // Username validation
        if (username.isEmpty()) {
            tusername.setError("Username is required");
            tusername.requestFocus();
            return false;
        }
        if (username.length() < 3) {
            tusername.setError("Username must be at least 3 characters long");
            tusername.requestFocus();
            return false;
        }

        // Name validation
        if (firstname.isEmpty()) {
            tfirstname.setError("First name is required");
            tfirstname.requestFocus();
            return false;
        }
        if (lastname.isEmpty()) {
            tlastname.setError("Last name is required");
            tlastname.requestFocus();
            return false;
        }

        // Phone validation
        if (phone.isEmpty()) {
            tphone.setError("Phone number is required");
            tphone.requestFocus();
            return false;
        }
        if (phone.length() < 10) {
            tphone.setError("Please enter a valid phone number");
            tphone.requestFocus();
            return false;
        }

        // Password validation
        if (password.isEmpty()) {
            tpassword.setError("Password is required");
            tpassword.requestFocus();
            return false;
        }
        if (password.length() < 6) {
            tpassword.setError("Password must be at least 6 characters long");
            tpassword.requestFocus();
            return false;
        }
        if (password1.isEmpty()) {
            tpassword1.setError("Please confirm your password");
            tpassword1.requestFocus();
            return false;
        }
        if (!password1.equals(password)) {
            tpassword1.setError("Passwords do not match");
            tpassword1.requestFocus();
            return false;
        }

        return true;
    }

    private void performRegistration() {
        String useremail = tuseremail.getText().toString().trim();
        String username = tusername.getText().toString().trim();
        String firstname = tfirstname.getText().toString().trim();
        String lastname = tlastname.getText().toString().trim();
        String phone = tphone.getText().toString().trim();
        String password = tpassword.getText().toString();
        String password1 = tpassword1.getText().toString();

        // Hash passwords
        String hashedPassword = hashPassword(password);
        String hashedPassword1 = hashPassword(password1);

        if (hashedPassword == null || hashedPassword1 == null) {
            Toast.makeText(this, "Error processing passwords", Toast.LENGTH_SHORT).show();
            return;
        }

        // Show progress to user
        Toast.makeText(this, "Processing registration...", Toast.LENGTH_SHORT).show();
        bregister.setEnabled(false);

        // Initialize RequestQueue if not already initialized
        if (rQueue == null) {
            rQueue = Volley.newRequestQueue(getApplicationContext());
        }

        StringRequest stringRequest = createRegistrationRequest(
                useremail, username, firstname, lastname, phone, hashedPassword, hashedPassword1);

        // Set timeout for the request
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                30000, // 30 seconds timeout
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
        ));

        // Add request to queue
        rQueue.add(stringRequest);
    }

    private StringRequest createRegistrationRequest(final String useremail, final String username,
                                                    final String firstname, final String lastname, final String phone,
                                                    final String hashedPassword, final String hashedPassword1) {

        return new StringRequest(Request.Method.POST,
                getResources().getString(R.string.url) + "app_api/register.php",
                this::handleRegistrationResponse,
                error -> {
                    bregister.setEnabled(true);
                    Log.e(TAG, "Registration Error: " + error.toString());
                    Toast.makeText(RegisterActivity.this,
                            "Network error occurred. Please try again.",
                            Toast.LENGTH_SHORT).show();
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("useremail", useremail);
                params.put("username", username);
                params.put("firstname", firstname);
                params.put("lastname", lastname);
                params.put("phone", phone);
                params.put("password", hashedPassword);
                params.put("password1", hashedPassword1);
                return params;
            }

            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> params = new HashMap<>();
                params.put("Content-Type", "application/x-www-form-urlencoded");
                params.put("X-Requested-With", "XMLHttpRequest");
                return params;
            }
        };
    }

    private void handleRegistrationResponse(String response) {
        bregister.setEnabled(true);
        Log.d(TAG, "Registration Response: " + response);

        try {
            JSONObject jsonObject = new JSONObject(response);
            String success = jsonObject.optString("success");
            String message = jsonObject.optString("message", "Unknown error occurred");

            if (success.equals("1")) {
                Toast.makeText(RegisterActivity.this, "Registration Successful!", Toast.LENGTH_SHORT).show();
                // Navigate to login screen
                Intent intent = new Intent(getBaseContext(), LoginActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(RegisterActivity.this, message, Toast.LENGTH_SHORT).show();
            }
        } catch (JSONException e) {
            Log.e(TAG, "JSON parsing error: " + e.getMessage());
            Toast.makeText(RegisterActivity.this,
                    "Error processing server response", Toast.LENGTH_SHORT).show();
        }
    }

    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(password.getBytes());
            byte[] byteData = md.digest();

            StringBuilder sb = new StringBuilder();
            for (byte b : byteData) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            Log.e(TAG, "Error hashing password: " + e.getMessage());
            return null;
        }
    }

    public void login(View v) {
        startActivity(new Intent(this, LoginActivity.class));
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (rQueue != null) {
            rQueue.cancelAll(TAG);
        }
    }
}*/