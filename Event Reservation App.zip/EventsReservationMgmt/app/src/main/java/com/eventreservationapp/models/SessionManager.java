package com.eventreservationapp.models;

import android.content.Context;
import android.content.SharedPreferences;

public class SessionManager {
    private static final String PREF_NAME = "EventReservationPref";
    private static final String KEY_IS_LOGGED_IN = "isLoggedIn";
    private static final String KEY_USER_ID = "userId";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_EMAIL = "email";
    private static final String KEY_FIRST_NAME = "firstName";
    private static final String KEY_LAST_NAME = "lastName";

    private SharedPreferences pref;
    private SharedPreferences.Editor editor;
    private Context context;

    public SessionManager(Context context) {
        this.context = context;
        pref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editor = pref.edit();
    }

    public void createLoginSession(int userId, String username, String email, String firstName, String lastName) {
        editor.putBoolean(KEY_IS_LOGGED_IN, true);
        editor.putInt(KEY_USER_ID, userId);
        editor.putString(KEY_USERNAME, username);
        editor.putString(KEY_EMAIL, email);
        editor.putString(KEY_FIRST_NAME, firstName);
        editor.putString(KEY_LAST_NAME, lastName);
        editor.commit();
    }

    public UserData getUserData() {
        if (!isLoggedIn()) {
            return null;
        }

        int userId = pref.getInt(KEY_USER_ID, 0);
        String username = pref.getString(KEY_USERNAME, "");
        String email = pref.getString(KEY_EMAIL, "");
        String firstName = pref.getString(KEY_FIRST_NAME, "");
        String lastName = pref.getString(KEY_LAST_NAME, "");

        return new UserData(userId, username, email, firstName, lastName);
    }

    public void updateUserData(UserData userData) {
        editor.putString(KEY_USERNAME, userData.getUsername());
        editor.putString(KEY_EMAIL, userData.getEmail());
        editor.putString(KEY_FIRST_NAME, userData.getFirstName());
        editor.putString(KEY_LAST_NAME, userData.getLastName());
        editor.commit();
    }

    public boolean isLoggedIn() {
        return pref.getBoolean(KEY_IS_LOGGED_IN, false);
    }

    public void logoutUser() {
        editor.clear();
        editor.commit();
    }
}