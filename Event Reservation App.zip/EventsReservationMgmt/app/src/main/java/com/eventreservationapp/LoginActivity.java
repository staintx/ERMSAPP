package com.eventreservationapp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {

    private static final String TAG = "LoginActivity";

    private EditText etEmail;
    private EditText etPassword;
    private Button btnLogin;
    private TextView tvRegister;
    private ProgressBar progressBar;
    private Context ctx;
    private RequestQueue rQueue;
    private String useremail;
    private String userpassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        ctx = this;

        // Initialize views and setup listeners
        initializeViews();

        // Setup login button
        setupLoginButton();

        // Set up register text click listener
        tvRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to RegisterActivity
                startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
            }
        });
    }

    private void initializeViews() {
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        tvRegister = findViewById(R.id.tvRegister);
        progressBar = findViewById(R.id.progressBar);
    }

    private void setupLoginButton() {
        btnLogin.setOnClickListener(view -> {
            if (validateInputs()) {
                loginUser();
            }
        });
    }

    private boolean validateInputs() {
        useremail = etEmail.getText().toString().trim();
        userpassword = etPassword.getText().toString().trim();

        if (useremail.isEmpty()) {
            etEmail.setError("Email is required");
            etEmail.requestFocus();
            return false;
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(useremail).matches()) {
            etEmail.setError("Please enter a valid email address");
            etEmail.requestFocus();
            return false;
        }

        if (userpassword.isEmpty()) {
            etPassword.setError("Password is required");
            etPassword.requestFocus();
            return false;
        }

        return true;
    }

    private void loginUser() {
        // Hash password before sending
        String hashedPassword = md5(userpassword);

        if (hashedPassword.isEmpty()) {
            Toast.makeText(ctx, "Error processing password", Toast.LENGTH_SHORT).show();
            return;
        }

        // Store hashed password
        userpassword = hashedPassword;

        // Show progress
        progressBar.setVisibility(View.VISIBLE);
        btnLogin.setEnabled(false);
        Toast.makeText(ctx, "Validating credentials...", Toast.LENGTH_SHORT).show();

        // Initialize RequestQueue if needed
        if (rQueue == null) {
            rQueue = Volley.newRequestQueue(getApplicationContext());
        }

        StringRequest stringRequest = createLoginRequest();

        // Set timeout
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                30000,  // 30 seconds timeout
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
        ));

        rQueue.add(stringRequest);
    }

    private StringRequest createLoginRequest() {
        return new StringRequest(Request.Method.POST,
                getResources().getString(R.string.url) + "app_api/login.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        handleLoginResponse(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressBar.setVisibility(View.GONE);
                        btnLogin.setEnabled(true);
                        Log.e(TAG, "Volley Error: " + error.toString());
                        if (error.networkResponse != null) {
                            Log.e(TAG, "Error Response Code: " + error.networkResponse.statusCode);
                            try {
                                String responseBody = new String(error.networkResponse.data);
                                Log.e(TAG, "Error Response Body: " + responseBody);
                            } catch (Exception e) {
                                Log.e(TAG, "Error getting error response body: " + e.getMessage());
                            }
                        }
                        Toast.makeText(ctx,
                                "Network error. Please check your connection and try again.",
                                Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("useremail", useremail);
                params.put("password", userpassword);  // Already hashed
                Log.d(TAG, "Login Parameters: " + params);
                return params;
            }

            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/x-www-form-urlencoded");
                headers.put("X-Requested-With", "XMLHttpRequest");
                return headers;
            }
        };
    }

    private void handleLoginResponse(String response) {
        progressBar.setVisibility(View.GONE);
        btnLogin.setEnabled(true);
        Log.d(TAG, "Raw Login Response: " + response);

        try {
            JSONObject jsonResponse = new JSONObject(response);
            String success = jsonResponse.optString("success");
            String message = jsonResponse.optString("message", "Unknown error occurred");

            if (success.equals("1")) {
                // Login successful
                JSONObject details = jsonResponse.getJSONObject("details");
                Toast.makeText(LoginActivity.this, "Login Successful!", Toast.LENGTH_SHORT).show();
                navigateToMainActivity(details);
            } else {
                // Login failed
                Toast.makeText(LoginActivity.this, message, Toast.LENGTH_LONG).show();
            }
        } catch (JSONException e) {
            Log.e(TAG, "JSON parsing error: " + e.getMessage());
            Log.e(TAG, "Response received: " + response);
            Toast.makeText(LoginActivity.this,
                    "Server response error. Please try again later.",
                    Toast.LENGTH_SHORT).show();
        }
    }

    private void navigateToMainActivity(JSONObject userDetails) {
        try {
            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
            // Pass user details as extras instead of storing in SharedPreferences
            intent.putExtra("user_id", userDetails.getString("user_id"));
            intent.putExtra("username", userDetails.getString("username"));
            intent.putExtra("useremail", userDetails.getString("useremail"));
            intent.putExtra("user_type", userDetails.getString("user_type"));

            // Add these extras if they exist
            if (userDetails.has("customer_id")) {
                intent.putExtra("customer_id", userDetails.getString("customer_id"));
            }
            if (userDetails.has("first_name") && userDetails.has("last_name")) {
                intent.putExtra("first_name", userDetails.getString("first_name"));
                intent.putExtra("last_name", userDetails.getString("last_name"));
            }

            startActivity(intent);
        } catch (JSONException e) {
            Log.e(TAG, "Error passing user details to MainActivity: " + e.getMessage());
            Toast.makeText(LoginActivity.this,
                    "Error starting main activity", Toast.LENGTH_SHORT).show();
        }
    }

    // MD5 hashing function
    private static String md5(final String s) {
        try {
            // Create MD5 Hash
            MessageDigest digest = MessageDigest.getInstance("MD5");
            digest.update(s.getBytes());
            byte[] messageDigest = digest.digest();

            // Create Hex String
            StringBuilder hexString = new StringBuilder();
            for (byte b : messageDigest) {
                String h = Integer.toHexString(0xFF & b);
                while (h.length() < 2)
                    h = "0" + h;
                hexString.append(h);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            Log.e(TAG, "Error hashing password: " + e.getMessage());
        }
        return "";
    }

    public void register(View v) {
        startActivity(new Intent(ctx, RegisterActivity.class));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (rQueue != null) {
            rQueue.cancelAll(TAG);
        }
    }
}
//============================================PREVIOUSLOGIN V1======================================

/*package com.eventreservationapp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {
    private static final String TAG = "LoginActivity";
    private EditText tuseremail, tuserpassword;
    private Button blogin;
    private Context ctx;
    private RequestQueue rQueue;
    private SharedPreferences sh;
    private String useremail;
    private String userpassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ctx = this;

        initializeViews();
        setupLoginButton();
    }

    private void initializeViews() {
        tuseremail = findViewById(R.id.useremail);
        tuserpassword = findViewById(R.id.userpassword);
        blogin = findViewById(R.id.login_btn);
    }

    private void setupLoginButton() {
        blogin.setOnClickListener(view -> {
            if (validateInputs()) {
                performLogin();
            }
        });
    }

    private boolean validateInputs() {
        useremail = tuseremail.getText().toString().trim();
        userpassword = tuserpassword.getText().toString().trim();

        if (useremail.isEmpty()) {
            tuseremail.setError("Email is required");
            tuseremail.requestFocus();
            return false;
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(useremail).matches()) {
            tuseremail.setError("Please enter a valid email address");
            tuseremail.requestFocus();
            return false;
        }

        if (userpassword.isEmpty()) {
            tuserpassword.setError("Password is required");
            tuserpassword.requestFocus();
            return false;
        }

        return true;
    }

    private void performLogin() {
        // Hash password before sending
        userpassword = hashPassword(userpassword);

        if (userpassword == null) {
            Toast.makeText(ctx, "Error processing password", Toast.LENGTH_SHORT).show();
            return;
        }

        // Show progress
        blogin.setEnabled(false);
        Toast.makeText(ctx, "Validating credentials...", Toast.LENGTH_SHORT).show();

        // Initialize RequestQueue if needed
        if (rQueue == null) {
            rQueue = Volley.newRequestQueue(getApplicationContext());
        }

        StringRequest stringRequest = createLoginRequest();

        // Set timeout
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                30000,  // 30 seconds timeout
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
        ));

        rQueue.add(stringRequest);
    }

    private StringRequest createLoginRequest() {
        return new StringRequest(Request.Method.POST,
                getResources().getString(R.string.url) + "app_api/validate.php",
                this::handleLoginResponse,
                error -> {
                    blogin.setEnabled(true);
                    Log.e(TAG, "Volley Error: " + error.toString());
                    if (error.networkResponse != null) {
                        Log.e(TAG, "Error Response Code: " + error.networkResponse.statusCode);
                        try {
                            String responseBody = new String(error.networkResponse.data);
                            Log.e(TAG, "Error Response Body: " + responseBody);
                        } catch (Exception e) {
                            Log.e(TAG, "Error getting error response body: " + e.getMessage());
                        }
                    }
                    Toast.makeText(ctx,
                            "Network error. Please check your connection and try again.",
                            Toast.LENGTH_SHORT).show();
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("useremail", useremail);
                params.put("userpassword", userpassword);
                Log.d(TAG, "Login Parameters: " + params);
                return params;
            }

            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/x-www-form-urlencoded");
                headers.put("X-Requested-With", "XMLHttpRequest");
                return headers;
            }
        };
    }

    private void handleLoginResponse(String response) {
        blogin.setEnabled(true);
        Log.d(TAG, "Raw Login Response: " + response);

        try {
            JSONObject jsonObject = new JSONObject(response);
            String success = jsonObject.optString("success");
            String message = jsonObject.optString("message", "Unknown error occurred");

            if (success.equals("1")) {
                JSONObject details = jsonObject.getJSONObject("details");
                saveUserDetails(details);
                Toast.makeText(LoginActivity.this, "Login Successful!", Toast.LENGTH_SHORT).show();
                navigateToMainActivity();
            } else {
                Toast.makeText(LoginActivity.this, message, Toast.LENGTH_SHORT).show();
            }
        } catch (JSONException e) {
            Log.e(TAG, "JSON parsing error: " + e.getMessage());
            Log.e(TAG, "Response received: " + response);
            Toast.makeText(LoginActivity.this,
                    "Server response error. Please try again later.",
                    Toast.LENGTH_SHORT).show();
        }
    }

    private void saveUserDetails(JSONObject details) throws JSONException {
        sh = getSharedPreferences("userdetail", MODE_PRIVATE);
        SharedPreferences.Editor editor = sh.edit();
        editor.putString("useremail", details.getString("useremail"));
        editor.putString("username", details.getString("username"));
        editor.putString("user_type", details.getString("user_type"));
        editor.putString("user_id", details.getString("user_id"));
        editor.apply();
    }

    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(password.getBytes());
            byte[] digest = md.digest();
            StringBuilder hexString = new StringBuilder();
            for (byte b : digest) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            Log.e(TAG, "Error hashing password: " + e.getMessage());
            return null;
        }
    }

    private void navigateToMainActivity() {
        Intent intent = new Intent(getBaseContext(), MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    public void register(View v) {
        startActivity(new Intent(ctx, RegisterActivity.class));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (rQueue != null) {
            rQueue.cancelAll(TAG);
        }
    }
}
*/