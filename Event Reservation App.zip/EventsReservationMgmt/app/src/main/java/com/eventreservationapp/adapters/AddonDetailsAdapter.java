package com.eventreservationapp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.eventreservationapp.R;
import com.eventreservationapp.models.OrderAddon;

import java.util.List;
import java.util.Locale;

public class AddonDetailsAdapter extends ArrayAdapter<OrderAddon> {

    public AddonDetailsAdapter(Context context, List<OrderAddon> addons) {
        super(context, 0, addons);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_addon_detail, parent, false);
        }

        OrderAddon addon = getItem(position);
        if (addon == null) {
            return convertView;
        }

        TextView tvAddonName = convertView.findViewById(R.id.tvAddonName);
        TextView tvAddonPrice = convertView.findViewById(R.id.tvAddonPrice);
        TextView tvAddonQuantity = convertView.findViewById(R.id.tvAddonQuantity);

        tvAddonName.setText(addon.getName());
        tvAddonPrice.setText("₱" + String.format(Locale.getDefault(), "%.2f", addon.getTotalPrice()));
        tvAddonQuantity.setText("x" + addon.getQuantity());

        return convertView;
    }

    /**
     * Calculate the total height needed by this adapter's views
     */
    public int calculateTotalHeight(ViewGroup parent) {
        int totalHeight = 0;
        for (int i = 0; i < getCount(); i++) {
            View listItem = getView(i, null, parent);
            listItem.measure(0, 0);
            totalHeight += listItem.getMeasuredHeight();
        }

        // Add divider heights
        totalHeight += (getCount() - 1) * 1; // 1px divider

        return totalHeight;
    }
}