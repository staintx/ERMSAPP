package com.eventreservationapp.models;

public class OrderAddon {
    private int orderAddonId;
    private int orderId;
    private int addonId;
    private int quantity;
    private double totalPrice;
    private String name;
    private String description;

    // Getters and setters
    public int getOrderAddonId() {
        return orderAddonId;
    }

    public void setOrderAddonId(int orderAddonId) {
        this.orderAddonId = orderAddonId;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getAddonId() {
        return addonId;
    }

    public void setAddonId(int addonId) {
        this.addonId = addonId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}