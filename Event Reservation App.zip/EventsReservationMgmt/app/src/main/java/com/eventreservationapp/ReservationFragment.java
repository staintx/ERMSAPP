package com.eventreservationapp;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.eventreservationapp.R;
import com.eventreservationapp.adapters.AddonDetailsAdapter;
import com.eventreservationapp.adapters.AddonSelectionAdapter;
import com.eventreservationapp.adapters.ReservationAdapter;
import com.eventreservationapp.models.Addon;
import com.eventreservationapp.models.Inclusion;
import com.eventreservationapp.models.OrderAddon;
import com.eventreservationapp.models.Package;
import com.eventreservationapp.models.Reservation;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class ReservationFragment extends Fragment {
    private static final String TAG = "ReservationFragment";
    private static final int REQUEST_TIMEOUT = 30000;

    // UI components
    private SwipeRefreshLayout swipeRefreshLayout;
    private ListView reservationListView;
    private ProgressBar progressBar;
    private TextView emptyView;
    private FloatingActionButton fabAddReservation;

    // Data
    private List<Reservation> reservationList;
    private ReservationAdapter reservationAdapter;
    private RequestQueue requestQueue;
    private SharedPreferences sharedPreferences;
    private String customerId;

    // Package and addon data
    private List<Package> packageList;
    private List<Addon> addonList;

    // Date formatters
    private final SimpleDateFormat serverDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
    private final SimpleDateFormat displayDateFormat = new SimpleDateFormat("MMM dd, yyyy hh:mm a", Locale.getDefault());
    private final SimpleDateFormat displayShortDateFormat = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault());

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_reservation, container, false);

        initializeViews(view);
        initializeData();
        setupListeners();

        // Load initial data
        loadReservations();

        return view;
    }

    /**
     * Initialize all UI components
     */
    private void initializeViews(View view) {
        swipeRefreshLayout = view.findViewById(R.id.swipeRefreshLayout);
        reservationListView = view.findViewById(R.id.reservationListView);
        progressBar = view.findViewById(R.id.progressBar);
        emptyView = view.findViewById(R.id.emptyView);
        fabAddReservation = view.findViewById(R.id.fabAddReservation);
    }

    /**
     * Initialize data objects
     */
    private void initializeData() {
        requestQueue = Volley.newRequestQueue(requireContext());
        sharedPreferences = requireActivity().getSharedPreferences("ERMSPrefs", Context.MODE_PRIVATE);
        customerId = sharedPreferences.getString("customer_id", "");

        reservationList = new ArrayList<>();
        reservationAdapter = new ReservationAdapter(requireContext(), reservationList);
        reservationListView.setAdapter(reservationAdapter);
        reservationListView.setEmptyView(emptyView);
    }

    /**
     * Set up event listeners
     */
    private void setupListeners() {
        // Set up refresh listener
        swipeRefreshLayout.setOnRefreshListener(this::loadReservations);

        // Set up FAB click listener
        fabAddReservation.setOnClickListener(v -> showAddReservationDialog());

        // Set up item click listener
        reservationListView.setOnItemClickListener((parent, view1, position, id) -> {
            Reservation reservation = reservationList.get(position);
            showReservationDetailsDialog(reservation);
        });
    }

    /**
     * Load all reservations for the current customer
     */
    private void loadReservations() {
        progressBar.setVisibility(View.VISIBLE);
        emptyView.setText("Loading reservations...");

        String url = getString(R.string.url) + "app_api/get_reservations.php?customer_id=" + customerId;

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                response -> {
                    progressBar.setVisibility(View.GONE);
                    swipeRefreshLayout.setRefreshing(false);

                    try {
                        processReservationsResponse(response);
                    } catch (JSONException e) {
                        Log.e(TAG, "JSON parsing error: " + e.getMessage());
                        Toast.makeText(requireContext(), "Error parsing data", Toast.LENGTH_SHORT).show();
                        emptyView.setText("Error loading reservations");
                    }
                },
                error -> {
                    progressBar.setVisibility(View.GONE);
                    swipeRefreshLayout.setRefreshing(false);
                    Toast.makeText(requireContext(), "Network error", Toast.LENGTH_SHORT).show();
                    emptyView.setText("Network error. Pull down to retry");
                    Log.e(TAG, "Volley Error: " + error.toString());
                });

        configureRequestRetryPolicy(stringRequest);
        requestQueue.add(stringRequest);
    }

    /**
     * Process the JSON response for reservations
     */
    private void processReservationsResponse(String response) throws JSONException {
        JSONObject jsonResponse = new JSONObject(response);
        String success = jsonResponse.getString("success");

        if (success.equals("1")) {
            reservationList.clear();

            if (jsonResponse.has("reservations")) {
                JSONArray reservationsArray = jsonResponse.getJSONArray("reservations");

                for (int i = 0; i < reservationsArray.length(); i++) {
                    JSONObject reservationObj = reservationsArray.getJSONObject(i);
                    Reservation reservation = parseReservationFromJson(reservationObj);
                    reservationList.add(reservation);
                }
            }

            reservationAdapter.notifyDataSetChanged();

            if (reservationList.isEmpty()) {
                emptyView.setText("No reservations found");
            }
        } else {
            String message = jsonResponse.getString("message");
            Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
            emptyView.setText("No reservations found");
        }
    }

    /**
     * Parse reservation object from JSON
     */
    private Reservation parseReservationFromJson(JSONObject reservationObj) throws JSONException {
        Reservation reservation = new Reservation();
        reservation.setOrderId(reservationObj.getInt("order_id"));
        reservation.setCustomerId(reservationObj.getInt("customer_id"));

        if (!reservationObj.isNull("package_id")) {
            reservation.setPackageId(reservationObj.getInt("package_id"));
        }

        reservation.setEventDate(reservationObj.getString("event_date"));

        if (!reservationObj.isNull("total_price")) {
            reservation.setTotalPrice(reservationObj.getDouble("total_price"));
        }

        reservation.setStatus(reservationObj.getString("status"));
        reservation.setEventLocation(reservationObj.getString("event_location"));
        reservation.setGuestNumber(reservationObj.getInt("guest_number"));

        if (reservationObj.has("package_name") && !reservationObj.isNull("package_name")) {
            reservation.setPackageName(reservationObj.getString("package_name"));
        }

        if (reservationObj.has("package_type") && !reservationObj.isNull("package_type")) {
            reservation.setPackageType(reservationObj.getString("package_type"));
        }

        // Get addons
        if (reservationObj.has("addons")) {
            reservation.setAddons(parseOrderAddonsFromJson(reservationObj.getJSONArray("addons")));
        }

        return reservation;
    }

    /**
     * Parse order addons array from JSON
     */
    private List<OrderAddon> parseOrderAddonsFromJson(JSONArray addonsArray) throws JSONException {
        List<OrderAddon> orderAddons = new ArrayList<>();

        for (int j = 0; j < addonsArray.length(); j++) {
            JSONObject addonObj = addonsArray.getJSONObject(j);

            OrderAddon orderAddon = new OrderAddon();
            orderAddon.setOrderAddonId(addonObj.getInt("order_addon_id"));
            orderAddon.setOrderId(addonObj.getInt("order_id"));
            orderAddon.setAddonId(addonObj.getInt("addon_id"));
            orderAddon.setQuantity(addonObj.getInt("quantity"));
            orderAddon.setTotalPrice(addonObj.getDouble("total_price"));
            orderAddon.setName(addonObj.getString("name"));
            orderAddon.setDescription(addonObj.optString("description", ""));

            orderAddons.add(orderAddon);
        }

        return orderAddons;
    }

    /**
     * Load packages for selection in spinner
     */
    private void loadPackages(Spinner packageSpinner) {
        String url = getString(R.string.url) + "app_api/get_packages.php";

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                response -> {
                    try {
                        processPackagesResponse(response, packageSpinner);
                    } catch (JSONException e) {
                        Log.e(TAG, "JSON parsing error: " + e.getMessage());
                        Toast.makeText(requireContext(), "Error parsing package data", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    Toast.makeText(requireContext(), "Network error loading packages", Toast.LENGTH_SHORT).show();
                    Log.e(TAG, "Volley Error: " + error.toString());
                });

        configureRequestRetryPolicy(stringRequest);
        requestQueue.add(stringRequest);
    }

    /**
     * Process the JSON response for packages
     */
    private void processPackagesResponse(String response, Spinner packageSpinner) throws JSONException {
        JSONObject jsonResponse = new JSONObject(response);
        String success = jsonResponse.getString("success");

        if (success.equals("1")) {
            packageList = new ArrayList<>();

            // Add a "None" option
            Package nonePackage = new Package();
            nonePackage.setPackageId(-1);
            nonePackage.setName("No Package (Custom)");
            packageList.add(nonePackage);

            if (jsonResponse.has("packages")) {
                JSONArray packagesArray = jsonResponse.getJSONArray("packages");

                for (int i = 0; i < packagesArray.length(); i++) {
                    JSONObject packageObj = packagesArray.getJSONObject(i);
                    Package pkg = parsePackageFromJson(packageObj);
                    packageList.add(pkg);
                }
            }

            setupPackageSpinner(packageSpinner);
        } else {
            String message = jsonResponse.getString("message");
            Toast.makeText(requireContext(), "Error loading packages: " + message, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Parse package object from JSON
     */
    private Package parsePackageFromJson(JSONObject packageObj) throws JSONException {
        Package pkg = new Package();
        pkg.setPackageId(packageObj.getInt("package_id"));
        pkg.setName(packageObj.getString("name"));
        pkg.setType(packageObj.getString("type"));
        pkg.setPrice(packageObj.getDouble("price"));
        pkg.setDescription(packageObj.optString("description", ""));

        // Get inclusions
        if (packageObj.has("inclusions")) {
            pkg.setInclusions(parseInclusionsFromJson(packageObj.getJSONArray("inclusions")));
        }

        return pkg;
    }

    /**
     * Parse inclusions array from JSON
     */
    private List<Inclusion> parseInclusionsFromJson(JSONArray inclusionsArray) throws JSONException {
        List<Inclusion> inclusions = new ArrayList<>();

        for (int j = 0; j < inclusionsArray.length(); j++) {
            JSONObject inclusionObj = inclusionsArray.getJSONObject(j);

            Inclusion inclusion = new Inclusion();
            inclusion.setInclusionId(inclusionObj.getInt("inclusion_id"));
            inclusion.setQuantity(inclusionObj.getInt("quantity"));
            inclusion.setCategory(inclusionObj.getString("category"));
            inclusion.setItemName(inclusionObj.getString("item_name"));
            inclusion.setPackageId(inclusionObj.getInt("package_id"));

            inclusions.add(inclusion);
        }

        return inclusions;
    }

    /**
     * Set up package spinner with data
     */
    private void setupPackageSpinner(Spinner packageSpinner) {
        List<String> packageNames = new ArrayList<>();
        for (Package pkg : packageList) {
            if (pkg.getPackageId() == -1) {
                packageNames.add(pkg.getName());
            } else {
                packageNames.add(pkg.getName() + " (" + pkg.getType() + ") - ₱" + pkg.getPrice());
            }
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(requireContext(),
                android.R.layout.simple_spinner_item, packageNames);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        packageSpinner.setAdapter(adapter);
    }

    /**
     * Load all available addons
     */
    private void loadAddons() {
        String url = getString(R.string.url) + "app_api/get_addons.php";

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                response -> {
                    try {
                        processAddonsResponse(response);
                    } catch (JSONException e) {
                        Log.e(TAG, "JSON parsing error: " + e.getMessage());
                        Toast.makeText(requireContext(), "Error parsing addon data", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    Toast.makeText(requireContext(), "Network error loading addons", Toast.LENGTH_SHORT).show();
                    Log.e(TAG, "Volley Error: " + error.toString());
                });

        configureRequestRetryPolicy(stringRequest);
        requestQueue.add(stringRequest);
    }

    /**
     * Process the JSON response for addons
     */
    private void processAddonsResponse(String response) throws JSONException {
        JSONObject jsonResponse = new JSONObject(response);
        String success = jsonResponse.getString("success");

        if (success.equals("1")) {
            addonList = new ArrayList<>();

            if (jsonResponse.has("addons")) {
                JSONArray addonsArray = jsonResponse.getJSONArray("addons");

                for (int i = 0; i < addonsArray.length(); i++) {
                    JSONObject addonObj = addonsArray.getJSONObject(i);

                    Addon addon = new Addon();
                    addon.setAddonId(addonObj.getInt("addon_id"));
                    addon.setName(addonObj.getString("name"));
                    addon.setDescription(addonObj.optString("description", ""));
                    addon.setPrice(addonObj.getDouble("price"));

                    addonList.add(addon);
                }
            }
        } else {
            String message = jsonResponse.getString("message");
            Toast.makeText(requireContext(), "Error loading addons: " + message, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Show dialog to add a new reservation
     */
    private void showAddReservationDialog() {
        BottomSheetDialog dialog = new BottomSheetDialog(requireContext());
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_add_reservation, null);
        dialog.setContentView(dialogView);

        // Initialize dialog views
        Spinner packageSpinner = dialogView.findViewById(R.id.packageSpinner);
        EditText eventLocationEditText = dialogView.findViewById(R.id.eventLocationEditText);
        EditText eventDateEditText = dialogView.findViewById(R.id.eventDateEditText);
        EditText eventTimeEditText = dialogView.findViewById(R.id.eventTimeEditText);
        EditText guestNumberEditText = dialogView.findViewById(R.id.guestNumberEditText);
        Button btnAddAddons = dialogView.findViewById(R.id.btnAddAddons);
        Button btnSubmitReservation = dialogView.findViewById(R.id.btnSubmitReservation);

        // Load packages for spinner
        loadPackages(packageSpinner);

        // Load addons for later selection
        loadAddons();

        // Date picker for event date
        eventDateEditText.setOnClickListener(v -> showDatePicker(eventDateEditText));

        // Time picker for event time
        eventTimeEditText.setOnClickListener(v -> showTimePicker(eventTimeEditText));

        // Create a list to store selected addons
        List<OrderAddon> selectedAddons = new ArrayList<>();

        // Add addons button click listener
        btnAddAddons.setOnClickListener(v -> {
            if (addonList != null && !addonList.isEmpty()) {
                showAddonsSelectionDialog(selectedAddons);
            } else {
                Toast.makeText(requireContext(), "No addons available", Toast.LENGTH_SHORT).show();
            }
        });

        // Submit reservation button click listener
        btnSubmitReservation.setOnClickListener(v -> {
            // Validate inputs
            if (validateReservationInputs(eventLocationEditText, eventDateEditText,
                    eventTimeEditText, guestNumberEditText)) {

                // Get selected package
                int packagePosition = packageSpinner.getSelectedItemPosition();
                Package selectedPackage = packageList.get(packagePosition);

                // Create reservation data
                String eventLocation = eventLocationEditText.getText().toString().trim();
                String eventDate = eventDateEditText.getText().toString().trim();
                String eventTime = eventTimeEditText.getText().toString().trim();
                int guestNumber = Integer.parseInt(guestNumberEditText.getText().toString().trim());

                // Submit reservation
                submitReservation(selectedPackage, eventLocation, eventDate, eventTime,
                        guestNumber, selectedAddons);

                dialog.dismiss();
            }
        });

        dialog.show();
    }

    /**
     * Show dialog to select addons
     */
    private void showAddonsSelectionDialog(List<OrderAddon> selectedAddons) {
        BottomSheetDialog dialog = new BottomSheetDialog(requireContext());
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_select_addons, null);
        dialog.setContentView(dialogView);

        ListView addonListView = dialogView.findViewById(R.id.addonListView);
        Button btnConfirmAddons = dialogView.findViewById(R.id.btnConfirmAddons);

        // Create adapter for addons selection
        AddonSelectionAdapter addonAdapter = new AddonSelectionAdapter(requireContext(), addonList, selectedAddons);
        addonListView.setAdapter(addonAdapter);

        // Confirm button click
        btnConfirmAddons.setOnClickListener(v -> {
            dialog.dismiss();
            Toast.makeText(requireContext(), selectedAddons.size() + " addons selected", Toast.LENGTH_SHORT).show();
        });

        dialog.show();
    }

    /**
     * Show date picker dialog
     */
    private void showDatePicker(EditText dateEditText) {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(requireContext(),
                (view, selectedYear, selectedMonth, selectedDay) -> {
                    calendar.set(selectedYear, selectedMonth, selectedDay);
                    dateEditText.setText(displayShortDateFormat.format(calendar.getTime()));
                }, year, month, day);

        // Set minimum date to today
        datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);

        datePickerDialog.show();
    }

    /**
     * Show time picker dialog
     */
    private void showTimePicker(EditText timeEditText) {
        Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(requireContext(),
                (view, selectedHour, selectedMinute) -> {
                    calendar.set(Calendar.HOUR_OF_DAY, selectedHour);
                    calendar.set(Calendar.MINUTE, selectedMinute);

                    SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a", Locale.getDefault());
                    timeEditText.setText(timeFormat.format(calendar.getTime()));
                }, hour, minute, false);

        timePickerDialog.show();
    }

    /**
     * Validate reservation inputs
     */
    private boolean validateReservationInputs(EditText locationEditText, EditText dateEditText,
                                              EditText timeEditText, EditText guestEditText) {
        boolean isValid = true;

        if (locationEditText.getText().toString().trim().isEmpty()) {
            locationEditText.setError("Location is required");
            isValid = false;
        }

        if (dateEditText.getText().toString().trim().isEmpty()) {
            dateEditText.setError("Date is required");
            isValid = false;
        }

        if (timeEditText.getText().toString().trim().isEmpty()) {
            timeEditText.setError("Time is required");
            isValid = false;
        }

        if (guestEditText.getText().toString().trim().isEmpty()) {
            guestEditText.setError("Number of guests is required");
            isValid = false;
        } else {
            try {
                int guests = Integer.parseInt(guestEditText.getText().toString().trim());
                if (guests <= 0) {
                    guestEditText.setError("Number of guests must be positive");
                    isValid = false;
                }
            } catch (NumberFormatException e) {
                guestEditText.setError("Invalid number");
                isValid = false;
            }
        }

        return isValid;
    }

    /**
     * Submit reservation to server
     */
    private void submitReservation(Package selectedPackage, String eventLocation,
                                   String eventDate, String eventTime, int guestNumber,
                                   List<OrderAddon> selectedAddons) {
        progressBar.setVisibility(View.VISIBLE);

        String url = getString(R.string.url) + "app_api/create_reservation.php";

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                response -> {
                    progressBar.setVisibility(View.GONE);

                    try {
                        JSONObject jsonResponse = new JSONObject(response);
                        String success = jsonResponse.getString("success");

                        if (success.equals("1")) {
                            Toast.makeText(requireContext(), "Reservation submitted successfully",
                                    Toast.LENGTH_SHORT).show();
                            loadReservations(); // Refresh list
                        } else {
                            String message = jsonResponse.getString("message");
                            Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        Log.e(TAG, "JSON parsing error: " + e.getMessage());
                        Toast.makeText(requireContext(), "Error processing response",
                                Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(requireContext(), "Network error", Toast.LENGTH_SHORT).show();
                    Log.e(TAG, "Volley Error: " + error.toString());
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("customer_id", customerId);

                if (selectedPackage.getPackageId() > 0) {
                    params.put("package_id", String.valueOf(selectedPackage.getPackageId()));
                }

                // Combine date and time
                String dateTimeStr = "";
                try {
                    Date date = displayShortDateFormat.parse(eventDate);
                    SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a", Locale.getDefault());
                    Date time = timeFormat.parse(eventTime);

                    Calendar dateCalendar = Calendar.getInstance();
                    Calendar timeCalendar = Calendar.getInstance();
                    dateCalendar.setTime(date);
                    timeCalendar.setTime(time);

                    dateCalendar.set(Calendar.HOUR_OF_DAY, timeCalendar.get(Calendar.HOUR_OF_DAY));
                    dateCalendar.set(Calendar.MINUTE, timeCalendar.get(Calendar.MINUTE));

                    dateTimeStr = serverDateFormat.format(dateCalendar.getTime());
                } catch (ParseException e) {
                    Log.e(TAG, "Date parsing error: " + e.getMessage());
                }

                params.put("event_date", dateTimeStr);
                params.put("event_location", eventLocation);
                params.put("guest_number", String.valueOf(guestNumber));

                // Add addons if any
                if (!selectedAddons.isEmpty()) {
                    try {
                        JSONArray addonsArray = new JSONArray();
                        for (OrderAddon addon : selectedAddons) {
                            JSONObject addonObj = new JSONObject();
                            addonObj.put("addon_id", addon.getAddonId());
                            addonObj.put("quantity", addon.getQuantity());
                            addonsArray.put(addonObj);
                        }
                        params.put("addons", addonsArray.toString());
                    } catch (JSONException e) {
                        Log.e(TAG, "JSON creation error: " + e.getMessage());
                    }
                }

                return params;
            }
        };

        configureRequestRetryPolicy(stringRequest);
        requestQueue.add(stringRequest);
    }

    /**
     * Show reservation details dialog
     */
    private void showReservationDetailsDialog(Reservation reservation) {
        BottomSheetDialog dialog = new BottomSheetDialog(requireContext());
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_reservation_details, null);
        dialog.setContentView(dialogView);

        // Initialize views
        TextView tvOrderId = dialogView.findViewById(R.id.tvOrderId);
        TextView tvPackageName = dialogView.findViewById(R.id.tvPackageName);
        TextView tvEventDate = dialogView.findViewById(R.id.tvEventDate);
        TextView tvEventLocation = dialogView.findViewById(R.id.tvEventLocation);
        TextView tvGuestNumber = dialogView.findViewById(R.id.tvGuestNumber);
        TextView tvStatus = dialogView.findViewById(R.id.tvStatus);
        TextView tvTotalPrice = dialogView.findViewById(R.id.tvTotalPrice);
        ListView addonsListView = dialogView.findViewById(R.id.addonsListView);
        Button btnCancelReservation = dialogView.findViewById(R.id.btnCancelReservation);

        // Set values
        tvOrderId.setText("Order #" + reservation.getOrderId());

        if (reservation.getPackageName() != null && !reservation.getPackageName().isEmpty()) {
            tvPackageName.setText(reservation.getPackageName() +
                    (reservation.getPackageType() != null ? " (" + reservation.getPackageType() + ")" : ""));
        } else {
            tvPackageName.setText("Custom Event (No Package)");
        }

        try {
            Date eventDate = serverDateFormat.parse(reservation.getEventDate());
            tvEventDate.setText(displayDateFormat.format(eventDate));
        } catch (ParseException e) {
            tvEventDate.setText(reservation.getEventDate());
        }

        tvEventLocation.setText(reservation.getEventLocation());
        tvGuestNumber.setText(String.valueOf(reservation.getGuestNumber()));
        tvStatus.setText(reservation.getStatus());
        tvTotalPrice.setText("₱" + reservation.getTotalPrice());

        // Set up addons list if any
        List<OrderAddon> addons = reservation.getAddons();
        if (addons != null && !addons.isEmpty()) {
            AddonDetailsAdapter addonAdapter = new AddonDetailsAdapter(requireContext(), addons);
            addonsListView.setAdapter(addonAdapter);
        } else {
            addonsListView.setVisibility(View.GONE);
            dialogView.findViewById(R.id.tvAddonsLabel).setVisibility(View.GONE);
        }

        // Set up cancel button based on status
        if ("Pending".equalsIgnoreCase(reservation.getStatus())) {
            btnCancelReservation.setVisibility(View.VISIBLE);
            btnCancelReservation.setOnClickListener(v -> {
                dialog.dismiss();
                showCancelConfirmationDialog(reservation.getOrderId());
            });
        } else {
            btnCancelReservation.setVisibility(View.GONE);
        }

        dialog.show();
    }

    /**
     * Show confirmation dialog for cancellation
     */
    private void showCancelConfirmationDialog(int orderId) {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(requireContext());
        builder.setTitle("Cancel Reservation");
        builder.setMessage("Are you sure you want to cancel this reservation?");
        builder.setPositiveButton("Yes", (dialog, which) -> cancelReservation(orderId));
        builder.setNegativeButton("No", (dialog, which) -> dialog.dismiss());
        builder.show();
    }

    /**
     * Cancel a reservation
     */
    private void cancelReservation(int orderId) {
        progressBar.setVisibility(View.VISIBLE);

        String url = getString(R.string.url) + "app_api/cancel_reservation.php";

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                response -> {
                    progressBar.setVisibility(View.GONE);

                    try {
                        JSONObject jsonResponse = new JSONObject(response);
                        String success = jsonResponse.getString("success");

                        if (success.equals("1")) {
                            Toast.makeText(requireContext(), "Reservation cancelled successfully",
                                    Toast.LENGTH_SHORT).show();
                            loadReservations(); // Refresh list
                        } else {
                            String message = jsonResponse.getString("message");
                            Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        Log.e(TAG, "JSON parsing error: " + e.getMessage());
                        Toast.makeText(requireContext(), "Error processing response",
                                Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(requireContext(), "Network error", Toast.LENGTH_SHORT).show();
                    Log.e(TAG, "Volley Error: " + error.toString());
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("order_id", String.valueOf(orderId));
                params.put("customer_id", customerId);
                return params;
            }
        };

        configureRequestRetryPolicy(stringRequest);
        requestQueue.add(stringRequest);
    }

    /**
     * Configure request timeout and retry policy
     */
    private void configureRequestRetryPolicy(StringRequest request) {
        request.setRetryPolicy(new DefaultRetryPolicy(
                REQUEST_TIMEOUT,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
    }
}


