package com.eventreservationapp.adapters;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.eventreservationapp.R;
import com.eventreservationapp.models.Reservation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ReservationAdapter extends ArrayAdapter<Reservation> {
    private static final String TAG = "ReservationAdapter";

    public ReservationAdapter(Context context, List<Reservation> reservations) {
        super(context, 0, reservations);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_reservation, parent, false);
        }

        Reservation reservation = getItem(position);
        if (reservation == null) {
            return convertView;
        }

        TextView tvOrderId = convertView.findViewById(R.id.tvOrderId);
        TextView tvEventDate = convertView.findViewById(R.id.tvEventDate);
        TextView tvPackage = convertView.findViewById(R.id.tvPackage);
        TextView tvStatus = convertView.findViewById(R.id.tvStatus);

        // Format date for display
        String formattedDate = formatEventDate(reservation.getEventDate());

        // Set values
        tvOrderId.setText("Order #" + reservation.getOrderId());
        tvEventDate.setText(formattedDate);

        if (reservation.getPackageName() != null && !reservation.getPackageName().isEmpty()) {
            tvPackage.setText(reservation.getPackageName());
        } else {
            tvPackage.setText("Custom (No Package)");
        }

        // Set status with appropriate color
        tvStatus.setText(reservation.getStatus());
        setStatusColor(tvStatus, reservation.getStatus());

        return convertView;
    }

    private String formatEventDate(String dateString) {
        String formattedDate = "N/A";
        try {
            SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            SimpleDateFormat outputFormat = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault());
            Date date = inputFormat.parse(dateString);
            formattedDate = outputFormat.format(date);
        } catch (ParseException e) {
            Log.e(TAG, "Date parsing error: " + e.getMessage());
            formattedDate = dateString;
        }
        return formattedDate;
    }

    private void setStatusColor(TextView textView, String status) {
        switch (status.toLowerCase()) {
            case "pending":
                textView.setTextColor(getContext().getResources().getColor(R.color.pending_color));
                break;
            case "confirmed":
                textView.setTextColor(getContext().getResources().getColor(R.color.confirmed_color));
                break;
            case "completed":
                textView.setTextColor(getContext().getResources().getColor(R.color.completed_color));
                break;
            case "cancelled":
                textView.setTextColor(getContext().getResources().getColor(R.color.cancelled_color));
                break;
            default:
                textView.setTextColor(getContext().getResources().getColor(R.color.black));
                break;
        }
    }
}