package com.eventreservationapp;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.eventreservationapp.R;
import com.eventreservationapp.databinding.FragmentAboutBinding;

import java.util.ArrayList;
import java.util.List;

public class AboutFragment extends Fragment {

    private FragmentAboutBinding binding;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentAboutBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setupCompanyInfo();
        setupSocialMediaLinks();
        setupContactInfo();
    }

    private void setupCompanyInfo() {
        binding.companyLogo.setImageResource(R.drawable.complogo);
        binding.companyName.setText(getString(R.string.company_name));
        binding.companyDescription.setText(getString(R.string.company_description));

        // Setup website button
        binding.websiteButton.setOnClickListener(v -> openWebPage(getString(R.string.website_url)));
    }

    private void setupSocialMediaLinks() {
        List<SocialMedia> socialMediaList = new ArrayList<>();
        socialMediaList.add(new SocialMedia("Facebook", R.drawable.facebook, getString(R.string.facebook_url)));

        SocialMediaAdapter adapter = new SocialMediaAdapter(socialMediaList, url -> openWebPage(url));

        binding.socialMediaRecyclerView.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
        binding.socialMediaRecyclerView.setAdapter(adapter);
    }

    private void setupContactInfo() {
        binding.address.setText(getString(R.string.company_address));
        binding.phone.setText(getString(R.string.company_phone));
        binding.email.setText(getString(R.string.company_email));

        // Setup phone call button
        binding.callButton.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:" + getString(R.string.company_phone)));
            startActivity(intent);
        });

        // Setup email button
        binding.emailButton.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_SENDTO);
            intent.setData(Uri.parse("mailto:" + getString(R.string.company_email)));
            intent.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.email_subject));
            startActivity(intent);
        });
    }

    private void openWebPage(String url) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(intent);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    public static class SocialMedia {
        private final String name;
        private final int iconResId;
        private final String url;

        public SocialMedia(String name, int iconResId, String url) {
            this.name = name;
            this.iconResId = iconResId;
            this.url = url;
        }

        public String getName() {
            return name;
        }

        public int getIconResId() {
            return iconResId;
        }

        public String getUrl() {
            return url;
        }
    }

    public static class SocialMediaAdapter extends RecyclerView.Adapter<SocialMediaAdapter.ViewHolder> {

        private final List<SocialMedia> socialMediaList;
        private final OnItemClickListener onItemClickListener;

        public interface OnItemClickListener {
            void onItemClick(String url);
        }

        public SocialMediaAdapter(List<SocialMedia> socialMediaList, OnItemClickListener onItemClickListener) {
            this.socialMediaList = socialMediaList;
            this.onItemClickListener = onItemClickListener;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_social_media, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            SocialMedia socialMedia = socialMediaList.get(position);
            holder.imageView.setImageResource(socialMedia.getIconResId());
            holder.textView.setText(socialMedia.getName());

            holder.itemView.setOnClickListener(v -> onItemClickListener.onItemClick(socialMedia.getUrl()));
        }

        @Override
        public int getItemCount() {
            return socialMediaList.size();
        }

        public static class ViewHolder extends RecyclerView.ViewHolder {
            public final ImageView imageView;
            public final TextView textView;

            public ViewHolder(View view) {
                super(view);
                imageView = view.findViewById(R.id.socialMediaIcon);
                textView = view.findViewById(R.id.socialMediaName);
            }
        }
    }
}